Installation:
Go to Python

CREDITS:
Art : Freepik
Sound : MixKit.co
Coding : GheeGhee2012