To set up the game follow the following instructions. you will only need to do this when you first download it 


WINDOWS:
1:download python3 at python.org

2:goto cmd and write 'pip install pysimpleGUI==4.60.1'

3:rename main.py to catll.pyw

5:delete launch.sh

4:launch catll.pyw

CREDITS:
https://docs.google.com/document/d/1Hgw_E1NpqnKv_7jcaQJ2gdp703mfxQ_kPEMSvCbwGfM/edit?usp=sharing